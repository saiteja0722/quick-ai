function fadeOutMessages() {
    var messages = document.getElementsByClassName('message');
        for (var i = 0; i < messages.length; i++) {
            var message = messages[i];
            setTimeout(function() {
                message.classList.add('fade-out');
            }, 5000);  
        }
    }
fadeOutMessages();  


window.addEventListener('DOMContentLoaded', function() {
    const contactInputs = document.querySelectorAll('.contact');

    contactInputs.forEach(input => {
        input.addEventListener('input', function() {
            var phone = this.value.replace(/\D/g, '').substring(0, 10);
            this.value = phone;
        });
    });
});


// email_form.js
$(document).ready(function() {
    setTimeout(function() {
        $('.error-message').fadeOut('slow');
    }, 5000); // 5000 milliseconds = 5 seconds
});


function showSelectedDateInput() {
    document.getElementById('selected_date_input').style.display = 'block';
    document.getElementById('hidden_selected_date_input').style.display = 'none';
}

function updateSelectedDate() {
    var selectedDateInput = document.getElementById('selected_date_input');
    var hiddenSelectedDateInput = document.getElementById('hidden_selected_date_input');
    hiddenSelectedDateInput.value = selectedDateInput.value;
}

function validateInput(inputElement) {
    const regex = /^[0-9]*\.?[0-9]*$/; // Regular expression to allow only numbers and at most one dot symbol (.)
    const inputValue = inputElement.value;
    
    if (!regex.test(inputValue)) {
      // If the input is invalid, remove the last character
      inputElement.value = inputValue.slice(0, -1);
    }
  }
  
  
  


