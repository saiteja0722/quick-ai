from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login as auth_login
from .models import *
from .forms import *

from django.contrib import messages

import datetime

from django.core.mail import EmailMessage

import socket 

from django.db.models import Q

from django.conf import settings


from login.models import *
from employee.models import *
from admins.models import *
from login.views import *

from django.contrib.auth.decorators import login_required

from django.db.models import Subquery, OuterRef






def approve(request, id=None):
    private_ip = None
    employee = None
    employee_name = request.POST.get('employee_name', '')

    if id:
        employee = get_object_or_404(Employee, id=id)
        employee_name = employee.user.username

    selected_date_str = request.GET.get('selected_date')
    client_name = request.GET.get('client_name')

    try:
        selected_date = datetime.datetime.strptime(selected_date_str, '%Y-%m-%d').date()
    except (ValueError, TypeError):
        selected_date = datetime.date.today()

    week_start = selected_date - datetime.timedelta(days=selected_date.weekday())
    week_end = week_start + datetime.timedelta(days=6)

    # Query calendar events based on date and, if provided, employee_name
    calendar_events = Approve.objects.filter(date__range=[week_start, week_end])
    if employee_name:
        calendar_events = calendar_events.filter(employee_name=employee_name)

    week_days = [week_start + datetime.timedelta(days=i) for i in range(7)]
    events_dict = {}

    for event_date in week_days:
        # Initialize events_dict with default event_name value '0'
        events_dict[event_date] = {'event_name': '0'}

        # Query CalendarEvent to get event_name based on client_name and employee_name
        matching_calendar_event = CalendarEvent.objects.filter(
            date=event_date,
            employee_name=employee_name,
            client_name=client_name,
        ).first()
        
        if matching_calendar_event:
            events_dict[event_date]['event_name'] = matching_calendar_event.event_name

    if request.method == 'GET':
        private_ip = get_physical_mac_address()
        print('Private IP:', private_ip)

        # Check if the private IP matches a director's IP
        if not Employee.objects.filter(ip_address=private_ip, user_type='director').exists():
            count = int(request.session.get('message_count', 0))
            count += 1
            request.session['message_count'] = count
            messages.error(request, 'Your MAC Address does not match')
            return redirect('login')

    context = {
        'private_ip': private_ip,
        'employee': employee,
        'employee_name': employee_name,
        'events_dict': events_dict,
        'selected_date': selected_date,
        'week_days': week_days,
        'client_name': client_name,
        'request': request,
        'en': employee.id if employee else None,
    }

    return render(request, "approve.html", context)





@login_required(login_url='/')
def status(request):
    private_ip = None
    selected_date=None
    week_dates=None
    k=None
    unique_names=None
    status=None
    status_display=None

    if request.method == 'GET':
        # Get the user's IP address
        private_ip = get_physical_mac_address()
        print('Private IP:', private_ip)

        # Check if the user's IP address is allowed
        if not Employee.objects.filter(ip_address=private_ip,user_type='director').exists():
            count = int(request.session.get('message_count', 0))
            count += 1
            request.session['message_count'] = count
            messages.error(request, 'Your MAC Address does not match')
            return redirect('another_page')

    if not request.user.is_authenticated or request.user.employee.user_type != 'director':
        return redirect('login')
    
    if request.method == 'POST':
        week_dates = []
        k = []
        reject_reason = request.POST.get('reject_reason', '')
        employees = request.POST.get('employee_name')

        selected_date_str = request.POST.get('selected_date')  # Get the selected date as a string
        status = request.POST.get('status')
        
        # Check if the form was submitted with a rejection reason
        
            

        try:
            if selected_date_str:
                selected_date = datetime.date.fromisoformat(selected_date_str)  # Convert the string to a date
            else:
                selected_date = datetime.date.today()  # Default to today's date if no date is provided

            # Calculate the start date (Monday) of the selected week
            monday = selected_date - datetime.timedelta(days=selected_date.weekday())
            # Calculate the end date (Sunday) of the selected week
            sunday = monday + datetime.timedelta(days=6)

        except ValueError:
            # Handle the case where the selected date is not in the correct format
            selected_date = datetime.date.today()  # Default to today's date if there's an issue with the format
            monday = selected_date - datetime.timedelta(days=selected_date.weekday())
            sunday = monday + datetime.timedelta(days=6)

        # Generate the list of dates for the selected week
        week_dates = [monday + datetime.timedelta(days=i) for i in range(7)]

        if status == "approved_status":
            k = Approve.objects.filter(date__range=(monday, sunday))
            unique_names = k.values('client_name', 'employee_name').distinct()
            status_display = "Approved"
            
                    
        elif selected_date and status == "in_review":
            # Get CalendarEvent records that match 'Emails' but not 'Approve'
            k = Emails.objects.filter(
        date__in=week_dates,
        client_name__in=CalendarEvent.objects.filter(date__in=week_dates).values('client_name'),
        employee_name__in=CalendarEvent.objects.filter(date__in=week_dates).values('employee_name'),
    ).exclude(
        Q(client_name__in=Approve.objects.filter(date__in=week_dates).values('client_name')) &
        Q(employee_name__in=Approve.objects.filter(date__in=week_dates).values('employee_name')) &
        Q(date__in=week_dates)
    )

            # Fetch 'event_name' from CalendarEvent based on matching 'client_name', 'employee_name', and 'date'
            for item in k:
                try:
                    event = CalendarEvent.objects.get(
                    client_name=item.client_name,
                    employee_name=item.employee_name,
                    date=item.date,
                    )
                    item.event_name = event.event_name
                except CalendarEvent.DoesNotExist:
                    pass

            unique_names = k.values('client_name', 'employee_name').distinct()
            status_display = "In Review"

           
        elif selected_date and status == "to_be_submitted":
            
    
            # Create a set of tuples with (employee_name, client_name) pairs from Emails
            excluded_pairs = set(Emails.objects.filter(date__in=week_dates).values_list('client_name','employee_name'))
    
            # Filter CalendarEvent objects based on the exclusion condition
            k = CalendarEvent.objects.filter(
             date__in=week_dates
             ).exclude(
        Q(client_name__in=[pair[0] for pair in excluded_pairs]) &
        Q(employee_name__in=[pair[1] for pair in excluded_pairs])
    ).values('user', 'client_name', 'employee_name', 'date')

            unique_names = k.values('client_name', 'employee_name').distinct()
    
            status_display = "To be submitted"
            
        
        else:
            k = Approve.objects.none()  # Set an empty queryset initially
            status = ""  # Set an empty status initially
            status_display = ""

        # Get unique combinations of client and employee names
        unique_names = []
        if k:  # Check if k is not empty
            unique_names = k.values('client_name', 'employee_name').distinct()
            
        action = request.POST.get('action')

        if action == 'approve':
            selected_rows = request.POST.getlist('row_selected')  # Get the selected rows from the form

            for selected_row in selected_rows:
                client_name, employee_name = selected_row.split('-')
                for date in week_dates:
                    formatted_date = date.strftime('%Y-%m-%d')

                    # Query the CalendarEvent model to get the correct event_name
                    try:
                        event = CalendarEvent.objects.get(
                    client_name=client_name,
                    employee_name=employee_name,
                    date=date,
                        )
                        event_name = event.event_name
                    except CalendarEvent.DoesNotExist:
                        event_name = '0'  # Set a default value if the event doesn't exist

                    if event_name:
                        approve_entry = Approve(
                    client_name=client_name,
                    employee_name=employee_name,
                    date=date,
                    event_name=event_name,
                    approvedBy=request.user.username if event_name!='0' else '',  # Store the username of the logged-in user
                    approvedDate=timezone.now() if event_name!='0' else None,  # Store the current timestamp
                        )
                        approve_entry.save()
                        
                    


            employee = get_object_or_404(Employee, user__username=employees)

            subject = 'Timesheet Approved'
            message = f"Dear {employee_name},\n\nYour timesheet for the period ({monday}) to ({sunday}) has been approved successfully."
            director_emails = Employee.objects.filter(user_type='director').values_list('email', flat=True)
            email = EmailMessage(subject, message, settings.EMAIL_HOST_USER, [employee.email], cc=director_emails)
            email.send()
            
            count = int(request.session.get('message_count', 0))
            count += 1
            request.session['message_count'] = count
            messages.success(request, "Billed hours has been approved successfully!")

            return redirect('status')
            
        if 'rejection' in request.POST:
            if reject_reason:
                selected_rows = request.POST.getlist('row_selected')  # Get the selected rows from the form

                for selected_row in selected_rows:
                    client_name, employee_name = selected_row.split('-')
                    for date in week_dates:
                        formatted_date = date.strftime('%Y-%m-%d')
                
                        calendar_event = CalendarEvent.objects.filter(client_name=client_name, employee_name=employee_name, date=date).first()
                        if calendar_event:
                            event_name = calendar_event.event_name  # Declare event_name here
                            if event_name != '0':
                                calendar_event.rejectedBy = request.user.username  # Store the username of the director
                                calendar_event.rejectedDate = timezone.now()  # Store the current timestamp
                            else:
                                calendar_event.rejectedBy = None  # Set to None when event_name is '0'
                                calendar_event.rejectedDate = None  # Set to None when event_name is '0'
                    
                            calendar_event.save()
                
                        Emails.objects.get(client_name=client_name, employee_name=employee_name, date=date).delete()
    
                employee = get_object_or_404(Employee, user__username=employee_name)
                subject = 'Timesheet Rejected'
                message = f"Dear {employee_name},\n\nYour timesheet for the period ({monday}) to ({sunday}) has been rejected because of {reject_reason}."
                director_emails = Employee.objects.filter(user_type='director').values_list('email', flat=True)
                email = EmailMessage(subject, message, settings.EMAIL_HOST_USER, [employee.email], cc=director_emails)
                email.send()
        
                count = int(request.session.get('message_count', 0))
                count += 1
                request.session['message_count'] = count
                messages.success(request, "Billed hours are rejected successfully!")
        
            return redirect('status')

        

    context = {
        'private_ip': private_ip,
        'selected_date': selected_date,
        'week_dates': week_dates,
        'k': k,
        'unique_names': unique_names,
        'status': status,
        'status_display': status_display,
    }

    return render(request, "status.html", context)


def save_data(request):
    employee_name = None
    private_ip = None
    all_employees = None
    employee = None

    if request.method == 'POST':
        # Retrieve form data
        client_name = request.POST.get('client_name')
        employee_name = request.POST.get('employee_name')
        dates = request.POST.getlist('date')
        event_names = request.POST.getlist('event_name')
        reject_reason = request.POST.get('reject_reason', '')
        
        for date, event_name in zip(dates, event_names):
            if event_name == '0':
                event_name = 0  # Convert '0' string to integer 0

            # Check if a record with the same combination of client_name, employee_name, and date exists
            existing_record = Approve.objects.filter(
                client_name=client_name,
                employee_name=employee_name,
                date=date
            ).first()

            if existing_record:
                existing_record.event_name = event_name
                existing_record.save()
            else:
                # Create a new record with the client_name
                Approve.objects.create(
                    client_name=client_name,
                    employee_name=employee_name,
                    date=date,
                    event_name=event_name
                )
        
        if 'rejection' in request.POST:
            if reject_reason:
                employee = get_object_or_404(Employee, user__username=employee_name)
                subject = 'Timesheet Rejected'
                message = f"Dear {employee_name},\n\nYour timesheet for the period ({week_start}) to ({week_end}) has been rejected because of {reject_reason}."
                director_emails = Employee.objects.filter(user_type='director').values_list('email', flat=True)
                email = EmailMessage(subject, message, settings.EMAIL_HOST_USER, [employee.email], cc=director_emails)
                email.send()

                director = Employee.objects.filter(user_type='director').first()
                clickeduser=director.user.username if director else ""
                # Delete corresponding entries from the Approve model for the rejected dates
                for date in dates:
                    da = datetime.datetime.strptime(date, '%Y-%m-%d').date()
                    calendar_event = CalendarEvent.objects.filter(client_name=client_name, employee_name=employee_name, date=da).first()
                    if calendar_event:
                        if calendar_event.event_name != '0':
                            calendar_event.rejectedBy = clickeduser  # Store the username of the director
                            calendar_event.rejectedDate = timezone.now()  # Store the current timestamp
                            calendar_event.save()
                        
                    Approve.objects.filter(employee_name=employee_name, date=da, client_name=client_name).delete()
                    Emails.objects.filter(employee_name=employee_name, date=da, client_name=client_name).delete()

                count = int(request.session.get('message_count', 0))
                count += 1
                request.session['message_count'] = count
                messages.success(request, "Billed hours are rejected successfully!")

            return redirect('status')

        # Handle approval logic
        elif 'save_button' in request.POST:
            count = int(request.session.get('message_count', 0))
            count += 1
            request.session['message_count'] = count
            messages.success(request, "Data is approved successfully!")

            employee_name = request.POST.get('employee_name')

            # Extract the week start and end dates
            week_start = datetime.datetime.strptime(dates[0], '%Y-%m-%d').date()
            week_end = datetime.datetime.strptime(dates[-1], '%Y-%m-%d').date()

            l = []
            for date, event in zip(dates, event_names):
                da = datetime.datetime.strptime(date, '%Y-%m-%d').date()
                l.append(da)

                try:
                    event_obj = Approve.objects.filter(date=da, employee_name=employee_name, client_name=client_name).first()

                    if event_obj is not None:
                        event_obj.event_name = event if event else '0'

                        if event != '0':
                            # Set the 'approvedBy' field to the director's name from the Employee model
                            director = Employee.objects.filter(user_type='director').first()
                            event_obj.approvedBy = director.user.username if director else ""
                            # Update the 'approvedDate' field to the current date and time
                            event_obj.approvedDate = datetime.datetime.now()
                        else:
                            # If event_name is zero, set 'approvedBy' to blank and 'approvedDate' to None (null)
                            event_obj.approvedBy = ""
                            event_obj.approvedDate = None

                        event_obj.save()
                    else:
                        # Create a new event with the 'approvedBy' and 'approvedDate' fields if the event_name is not zero
                        if event != '0':
                            # Set the 'approvedBy' field to the director's name from the Employee model
                            director = Employee.objects.filter(user_type='director').first()
                            approvedBy = director.user.username if director else ""
                            Approve.objects.create(
                                client_name=client_name,
                                employee_name=employee_name,
                                date=da,
                                event_name=event if event else '0',
                                approvedBy=approvedBy,
                                approvedDate=datetime.datetime.now()
                            )

                except Approve.MultipleObjectsReturned:
                    # Handling MultipleObjectsReturned exception, if needed...
                    pass

            employee = get_object_or_404(Employee, user__username=employee_name)

            subject = 'Timesheet Approved'
            message = f"Dear {employee_name},\n\nYour timesheet for the period ({week_start}) to ({week_end}) has been approved successfully."
            director_emails = Employee.objects.filter(user_type='director').values_list('email', flat=True)
            email = EmailMessage(subject, message, settings.EMAIL_HOST_USER, [employee.email], cc=director_emails)
            email.send()

            return redirect('status')

        id = request.user.id
        if id:
            employee = get_object_or_404(Employee, user_id=id)
            employee_name = employee.user.username
        else:
            # Handle the case when the employee is not found
            employee = None
            employee_name = None

        selected_date = None
        en = None

        if request.method == 'POST':
            week_days = []
            selected_date_str = request.POST.get('selected_date')

            if selected_date_str:
                selected_date = datetime.datetime.strptime(selected_date_str, '%Y-%m-%d').date()
            else:
                selected_date = datetime.date.today()

            if 'employee_name' in request.POST:
                en = request.POST['employee_name']
            else:
                en = employee_name

        else:
            selected_date = datetime.date.today()

        week_start = selected_date - datetime.timedelta(days=selected_date.weekday())
        week_end = week_start + datetime.timedelta(days=6)
        events = Approve.objects.filter(date__range=[week_start, week_end])

        # Filter events by selected employee name if provided
        if en:
            events = events.filter(employee_name=en)

        week_days = [(week_start + datetime.timedelta(days=i)) for i in range(7)]
        events_dict = {}
        for event_date in week_days:
            event = events_dict.get(event_date)
            if event:
                events_dict[event_date].event_name = event.event_name
            else:
                events_dict[event_date] = Approve(date=event_date, event_name=0)

        for event in events:
            if event.date in events_dict:
                events_dict[event.date].event_name = event.event_name
            else:
                events_dict[event.date] = event

        context = {
        'employee': employee,
        'private_ip': private_ip,
        'employee_name': employee_name,
        'events_dict': events_dict,
        'selected_date': selected_date,
        'week_days': week_days,
        'request': request,
        'en': en,
        'all_employees': all_employees,
    }
        

        
        
        




    elif request.method == 'GET':
        private_ip = get_physical_mac_address()
        print('Private IP:', private_ip)

        if not Employee.objects.filter(ip_address=private_ip,user_type='director').exists():
            count = int(request.session.get('message_count', 0))
            count += 1
            request.session['message_count'] = count
            messages.error(request, 'Your MAC Address will not match')
            return redirect('login')

    return render(request, 'approve.html', context)















