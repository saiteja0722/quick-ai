from django.urls import path
from .views import *

urlpatterns=[
    path('', status, name='status'),
    path('approve/<int:id>/', approve, name='approve_with_id'),
    path('savedata/', save_data, name='savedata'),
]