from django.shortcuts import redirect
from django.urls import reverse

class PreventLoginRedirectionMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.user.is_authenticated and request.path == reverse('login'):
            user_type = request.user.employee.user_type if hasattr(request.user, 'employee') else None

            if user_type == 'employee':
                return redirect('calendar')  
            elif user_type == 'hr':
                return redirect('admin_page')  
            elif user_type == 'director':
                return redirect('status')
            

        response = self.get_response(request)
        return response
