from django.urls import path
from .views import *

urlpatterns=[
    
    path('', admin_page, name='admin_page'),
    path('logdata/',Log_data,name='logdata'),
    path('hrip/',hr_ip_addresses,name='hr_ip'),
    path('client/',client_store, name='client_store'),
]