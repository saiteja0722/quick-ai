from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login as auth_login
from .models import *
from .forms import *

from django.contrib import messages

from django.http import HttpResponse, HttpResponseRedirect

from django.contrib.auth.decorators import login_required

import datetime



from django.urls import reverse

from django.core.mail import EmailMessage
from pretty_html_table import build_table

import pandas as pd

import socket 

from django.db import transaction

from django.db.models import Q

from django.conf import settings




from admins.models import *
from approve.models import *
from login.views import *


@login_required(login_url='login')
def calendar_view(request):
    private_ip = None
    if request.method == 'GET':
        # Get the user's IP address
        private_ip = get_physical_mac_address()
        print('Private IP:', private_ip)

        # Check if the user's IP address is allowed
        if not Employee.objects.filter(ip_address=private_ip,user_type='employee').exists():
            count = int(request.session.get('message_count', 0))
            count += 1
            request.session['message_count'] = count
            messages.error(request, 'Your MAC Address does not match')
            return redirect('another_page')

    employee = get_object_or_404(Employee, user=request.user)
    if not request.user.is_authenticated or request.user.employee.user_type != 'employee':
        return redirect('login')
    
    if 'submit_client' in request.POST:
        selected_client = request.POST.get('selected_client', None)
        if selected_client is not None:
            employee = Employee.objects.get(user=request.user)
            employee.client_name = selected_client
            employee.save()

    if request.method == 'POST':
        if 'mails' in request.POST:
            client_name = request.POST.get('client_name')
            employee_name = request.POST.get('employee_name')
            dates = request.POST.getlist('date')
            event_names = request.POST.getlist('event_name')
            
            director = Employee.objects.filter(user_type='director').first()
            approveuser=director.user.username
            


            with transaction.atomic():
                for date, event_name in zip(dates, event_names):
                    selected_date = datetime.datetime.strptime(date, '%Y-%m-%d').date()
                    # Check if an entry with the same employee_name and date already exists
                    if not Emails.objects.filter(client_name=client_name ,employee_name=employee_name, date=selected_date).exists():
                        # Retrieve the username and set the 'addedBy' field
                        username = request.user.username

                        email_entry = Emails.objects.create(
                    client_name=client_name,
                    employee_name=employee_name,
                    date=selected_date,
                    
                )
                        email_entry.save()


            start_date = datetime.datetime.strptime(dates[0], '%Y-%m-%d').date()
            end_date = datetime.datetime.strptime(dates[-1], '%Y-%m-%d').date()

            # Check if data exists in the Approve model
            events = Approve.objects.filter(
                Q(date__range=[start_date, end_date]) & Q(employee_name=employee_name)
                )

            if not events.exists():
                # Data not found in the Approve model, use data from the CalendarEvent model
                events = CalendarEvent.objects.filter(
                Q(date__range=[start_date, end_date]) & Q(employee_name=employee_name) & Q(client_name=client_name)
             )

            dates = [start_date + datetime.timedelta(days=i) for i in range(7)]
            date_strings = [date.strftime('%Y-%m-%d') for date in dates]

            table_data = [
                    ["", "",] + date_strings,
                ["Client Name", "Employee Name", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
                 ]

            row_data = [client_name, employee_name] + [''] * len(date_strings)  

            for event in events:
                if event.date.strftime('%Y-%m-%d') in date_strings:
                    index = date_strings.index(event.date.strftime('%Y-%m-%d')) + 2
                    row_data[index] = event.event_name

            table_data.append(row_data)


            df = pd.DataFrame(table_data[1:], columns=table_data[0])  

            table_html = build_table(df, 'blue_light')

            subject = 'Time sheet Submission'
            review_url = request.build_absolute_uri(
    reverse('approve_with_id', args=[employee.id])
) + f'?selected_date={selected_date}&client_name={client_name}'


            review_button_html = f'<a href="{review_url}" style="display:inline-block; background-color:#3498db; color:#ffffff; padding:10px 20px; text-decoration:none;">Review</a>'
            message = f'''
        <html>
            <body>
                <h1>Time sheet Data</h1>
            
                <p>Dear {approveuser},</p>
                <p>This is {employee_name}. My timesheet for the period ({date_strings[0]}) to ({date_strings[-1]}) has been submited successfully. please review and approve the timesheet.</p>
                {table_html}

                <p>Thanks in advance! It's appreciated.</p>

                <h2>{review_button_html}</h2>
            </body>
        </html>
        ''' 
            director_emails = Employee.objects.filter(user_type='director').values_list('email', flat=True)
            email = EmailMessage(subject, message, settings.EMAIL_HOST_USER , director_emails, cc=[employee.email])
            email.content_subtype = 'html'
            email.send()
            messages.success(request,"Email has been sent to the Approver successfully..!")

            return redirect('calendar')
        
        

        if request.method == 'POST':
            
            
            employee = Employee.objects.get(user=request.user)
        
            
            
            selected_date_str = request.POST.get('selected_date')

            if selected_date_str:
                selected_date = datetime.datetime.strptime(selected_date_str, '%Y-%m-%d').date()
            else:
                selected_date = datetime.date.today()
        else:
            selected_date = datetime.date.today()


        if 'client_name' in request.POST:
            cn = request.POST['client_name']
        else:
            cn = None

        if 'employee_name' in request.POST:
            en = request.POST['employee_name']
        else:
            en = None

        dates = request.POST.getlist('date')
        events = request.POST.getlist('event_name')

        for date, event in zip(dates, events):
            da = datetime.datetime.strptime(date, '%Y-%m-%d').date()

            try:
                event_obj = CalendarEvent.objects.filter(
            user=request.user,
            client_name=cn,  # Match client_name
            employee_name=en,  # Match employee_name
            date=da  # Match date
        ).first()

                if event_obj is not None:
                    # Check if the existing client_name matches before updating
                    if event_obj.client_name == cn:
                        # Get the existing client_name and update other fields
                       
                        event_obj.employee_name = en
                        event_obj.event_name = event if event else '0'
                        event_obj.save()
                else:
                    # Create a new entry
                    CalendarEvent.objects.create(
                user=request.user,
                client_name=cn,
                employee_name=en,
                date=da,
                event_name=event if event else '0'
            )
            except CalendarEvent.MultipleObjectsReturned:
                events = CalendarEvent.objects.filter(user=request.user, date=da)
                first_event = events.first()
                first_event.client_name = cn
                first_event.employee_name = en
                first_event.event_name = event if event else 0
                first_event.save()
        
        

        if 'save_button' in request.POST:
            count = int(request.session.get('message_count', 0))
            count += 1
            request.session['message_count'] = count
            messages.success(request, "Billed hours saved successfully!")

            client_name = request.POST.get('client_name')
            employee_name = request.POST.get('employee_name')
            dates = request.POST.getlist('date')
            events = request.POST.getlist('event_name')

            # Retrieve the username and set the 'addedBy' field
            username = request.user.username

            for date, event in zip(dates, events):
                da = datetime.datetime.strptime(date, '%Y-%m-%d').date()

                try:
                    event_obj = CalendarEvent.objects.get(user=request.user, date=da, client_name=client_name, employee_name=employee_name)

                    event_obj.event_name = event

                    if event != '0':
                        # Set the 'addedBy' field to the current username
                        event_obj.addedBy = username
                        # Update the 'addedDate' field to the current date and time
                        event_obj.addedDate = datetime.datetime.now()
                    else:
                        # If event_name is zero, set 'addedBy' to blank and 'addedDate' to None (null)
                        event_obj.addedBy = ""
                        event_obj.addedDate = None

                    event_obj.save()

                except CalendarEvent.DoesNotExist:
                    # Create a new event if it doesn't exist
                    if event != '0':
                        CalendarEvent.objects.create(
                    user=request.user,
                    client_name=client_name,
                    employee_name=employee_name,
                    date=da,
                    event_name=event,
                    addedBy=username if event != '0' else "",
                    addedDate=datetime.datetime.now() if event != '0' else None
                        )

            return redirect('calendar')


    else:
        selected_date = datetime.date.today()

    id = request.user.id  # Retrieve the ID from the logged-in user
    employee = get_object_or_404(Employee, user_id=id)
    employee_name = employee.user.username
    client_name = employee.client_name

    week_start = selected_date - datetime.timedelta(days=selected_date.weekday())
    week_end = week_start + datetime.timedelta(days=6)
    events = CalendarEvent.objects.filter(user=request.user, date__range=[week_start, week_end])
    week_days = [(week_start + datetime.timedelta(days=i)) for i in range(7)]
    # events_dict = {event.date: event for event in events}
    
    client_data=ClientName.objects.all()
    
    # Create a dictionary to store events organized by date and client_name
    events_dict = {}

    # Iterate through the week days and initialize the events_dict
    for date in week_days:
        events_dict[date] = {}

    # Retrieve events from the database and populate the events_dict
    events = CalendarEvent.objects.filter(user=request.user, date__range=[week_start, week_end])
    for event in events:
        events_dict[event.date][event.client_name] = event
    

    context = {
        'private_ip':private_ip,
        'my_client':client_data,
'employee_name': employee_name,
'client_name':client_name,
'events_dict': events_dict,
'selected_date': selected_date,
'week_days': week_days,
'request': request,
}

    return render(request, 'sheet.html', context)


@login_required(login_url='/')
def data(request):
    if not request.user.is_authenticated or request.user.employee.user_type != 'employee':
        return redirect('login')

    id = request.user.id  # Retrieve the ID from the logged-in user
    if request.method == 'POST':
        cn = request.POST['client_name']
        en = request.POST['employee_name']
        dates = request.POST.getlist('date')
        events = request.POST.getlist('event_name')

        for date, event in zip(dates, events):
            da = datetime.datetime.strptime(date, '%Y-%m-%d').date()

            try:
                event_obj = CalendarEvent.objects.filter(user=request.user, date=da).first()
                if event_obj is not None:
                    event_obj.client_name = cn
                    event_obj.employee_name = en
                    event_obj.event_name = event if event else 0
                    event_obj.save()
                else:
                    CalendarEvent.objects.create(user=request.user, client_name=cn, employee_name=en, date=da, event_name=event if event else 0)
            except CalendarEvent.MultipleObjectsReturned:
                events = CalendarEvent.objects.filter(user=request.user, date=da)
                first_event = events.first()
                first_event.client_name = cn
                first_event.employee_name = en
                first_event.event_name = event if event else 0
                first_event.save()
        # messages.success(request,"Data will be saved successfully!..")
    return HttpResponseRedirect(request.META.get('HTTP_REFERER', '/'))