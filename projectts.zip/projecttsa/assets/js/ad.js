const collapsibleBtns = document.querySelectorAll('.btn');

      collapsibleBtns.forEach((btn) => {
        btn.addEventListener('click', function () {
          this.parentNode.classList.toggle('active');
          const content = this.nextElementSibling;
          if (content.style.display === 'flex') {
            content.style.display = 'none';
          } else {
            content.style.display = 'flex';
          }
        });
      });

      document.addEventListener('DOMContentLoaded', function () {
        const addButton = document.getElementById('addButton');
        const collapsible = document.querySelector('.collapsible');

        addButton.addEventListener('click', function () {
          collapsible.classList.toggle('active');
        });
      });


     // Get all input fields and select elements
const inputsAndSelects = document.querySelectorAll('input[type="text"], input[type="number"], input[type="email"], input[type="password"], select');

// Add event listeners to handle input field and select element selection
inputsAndSelects.forEach((element) => {
  element.addEventListener('focus', function () {
    this.classList.add('selected');
  });

  element.addEventListener('blur', function () {
    this.classList.remove('selected');
  });

  element.addEventListener('change', function () {
    if (this.value !== '') {
      this.classList.add('selected');
    } else {
      this.classList.remove('selected');
    }
  });
});

