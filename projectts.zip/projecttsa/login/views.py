from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login as auth_login
from .models import *

from django.contrib.auth.models import User

from django.contrib.auth import login, logout
from django.contrib import messages

import uuid




from django.db.models import Q


from admins.models import *
from employee.models import *
from approve.models import *


from django.http import Http404

from django.contrib.auth.decorators import login_required


def is_user_authenticated(user):
    return user.is_authenticated









from getmac import get_mac_address

def get_physical_mac_address():
    try:
        mac_address = get_mac_address()
        mac=mac_address.replace(':','-')
        return mac.upper()
    
    except Exception as e:
        print("Error:", e)
        return None

mac_address = get_physical_mac_address()
if mac_address:
    print("Physical MAC Address:", mac_address)
else:
    print("Physical MAC Address not found.")




    





def hr(request):
    if request.method == 'POST':
        if 'register' in request.POST:
            name = request.POST['name']
            employee_id = request.POST['employee_id']
            email=request.POST['email']
            ip_address=request.POST['ip_address']
            password = request.POST['password']
            user_type = request.POST.get('user_type') 

            if User.objects.filter(username=name).exists():
                messages.error(request,"Username already exists")
                return redirect('register')

            user = User.objects.create_user(username=name, password=password)
            employee = Employee(user=user, employee_id=employee_id, user_type=user_type, email=email, ip_address=ip_address)
            employee.save()
            messages.success(request,'Your Account is created successfully!.. ')
            return redirect('login')  
        
    elif request.method == 'GET':
        # Get the user's IP address
        private_ip = get_physical_mac_address()
        print('Private IP:', private_ip)

        # Check if the user's IP address is allowed
        if not HrIPAddress.objects.filter(ip_address=private_ip).exists():
            count = int(request.session.get('message_count', 0))
            count += 1
            request.session['message_count'] = count
            messages.error(request, 'Your MAC Address will not match')
            return redirect('login')
        


    instances = Employee.objects.all()
    context = {'instances': instances, 'private_ip':private_ip}
    return render(request, 'register.html', context)






def login_view(request):
    private_ip = None
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            employee = user.employee
            if employee.user_type == 'employee':
                return redirect('calendar')
            elif employee.user_type == 'hr':
                return redirect('admin_page')
            elif employee.user_type == 'director':
                return redirect('status')
        else:
            messages.error(request, 'Invalid username or password')

    # elif request.method == 'GET':
    #     # Get the user's IP address
    #     private_ip = get_physical_mac_address()
    #     print('Private IP:', private_ip)

    #     # Check if the user's IP address is allowed
    #     if not Employee.objects.filter(ip_address=private_ip).exists():
    #         count = int(request.session.get('message_count', 0))
    #         count += 1
    #         request.session['message_count'] = count
    #         messages.error(request, 'Your MAC Address does not match')
    #         return redirect('site_cant')

    # context={'private_ip':private_ip}
    return render(request, 'login.html')

def logout_view(request):
    if request.user.is_authenticated:
        logout(request)
        messages.error(request, "You are Logged Out!")
    return redirect('login')

def site_cant(request):
    return render(request, 'site_cant.html')

@login_required(login_url='login')
def another_page(request):
    return render(request,'ip_address.html')
