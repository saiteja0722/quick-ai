from django.db import models
from django.contrib.auth.models import User

from django.utils import timezone


class Approve(models.Model):
    client_name = models.CharField(max_length=100)
    employee_name = models.CharField(max_length=100)
    date = models.DateField()
    # event_name is working hours.
    event_name = models.CharField(max_length=100, default='0')
    approvedBy = models.CharField(max_length=50, blank=True, null=True)  
    approvedDate = models.DateTimeField(default=timezone.now, null=True)
    
    def __str__(self):
        return f"{self.employee_name} - {self.client_name} - {self.date.strftime('%Y-%m-%d')} - {self.event_name}"
    
    
        

    


    

    

