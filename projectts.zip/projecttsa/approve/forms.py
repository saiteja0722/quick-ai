from django import forms
from .models import *

class SearchForm(forms.Form):
    employee_name = forms.CharField(max_length=100, required=False)
    selected_date = forms.DateField(required=False)