from django.db import models



class HrIPAddress(models.Model):
    employee_name=models.CharField(max_length=50, default='', null=True)
    ip_address = models.CharField(max_length=17, unique=True, default='', null=True)

    def __str__(self):
        return f"{self.employee_name} - {self.ip_address}"
    

    
class LogData(models.Model):
    employee_name = models.CharField(max_length=50, unique=True)
    addedBy = models.CharField(max_length=50, blank=True, null=True)
    addedDate = models.DateTimeField(null=True)
    updatedBy = models.CharField(max_length=50, blank=True, null=True)
    updatedDate = models.DateTimeField(null=True)
    deletedBy = models.CharField(max_length=50, blank=True, null=True)
    deletedDate = models.DateTimeField(null=True)

    def __str__(self):
        return f"{self.addedBy} - {self.updatedBy} - {self.deletedBy}"
    
class ClientName(models.Model):
    clients=models.CharField(max_length=50,unique=True)

