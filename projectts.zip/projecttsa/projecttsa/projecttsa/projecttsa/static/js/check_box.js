function validateForm() {
    var checkboxes = document.getElementsByName('row_selected');
    var isChecked = false;
    
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            isChecked = true;
            break;
        }
    }
    
    if (!isChecked) {
        alert('Please select at least one row.');
        return false;  // Prevent form submission
    }
    
    return true;  // Allow form submission
}