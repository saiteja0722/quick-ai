const rejectButton = document.getElementById('rejectButton');
const textareaContainer = document.getElementById('textareaContainer');
const rejectReason = document.querySelector('.rejectReason');

rejectButton.addEventListener('click', () => {
    if (textareaContainer.style.display === 'none' || textareaContainer.style.display === '') {
        textareaContainer.style.display = 'block';
        rejectReason.setAttribute('required', 'required');
    } else {
        textareaContainer.style.display = 'none';
        rejectReason.removeAttribute('required');
    }
});