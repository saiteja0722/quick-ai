from django.db import models

from django.contrib.auth.models import User



class Employee(models.Model):
    USER_TYPES = (
        ('employee', 'Employee'),
        ('hr', 'HR'),
        ('director', 'Director'),
    )
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    employee_id = models.CharField(max_length=20)
    user_type = models.CharField(max_length=10, choices=USER_TYPES)
    email=models.EmailField(default='', null=True)
    ip_address = models.CharField(max_length=17, default='', null=True)
    client_name=models.CharField(max_length=25,default='',null=True)
    
    def __str__(self):
        return f"{self.user.username} - {self.user_type}"