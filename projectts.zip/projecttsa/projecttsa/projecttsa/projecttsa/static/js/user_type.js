var formContainers = document.querySelectorAll('.form-container');
  
      for (var i = 0; i < formContainers.length; i++) {
          var userTypeSelect = formContainers[i].querySelector('.user-type');
          var ipAddressContainer = formContainers[i].querySelector('.ip-address-container');
          var clientNameContainer = formContainers[i].querySelector('.client-name-container');
  
          // Check initial value on page load
          if (userTypeSelect.value === "director") {
              ipAddressContainer.style.display = "block";
          } else {
              ipAddressContainer.style.display = "none";
          }
  
          if (userTypeSelect.value === "employee") {
              clientNameContainer.style.display = "block";
          } else {
              clientNameContainer.style.display = "none";
          }
  
          userTypeSelect.addEventListener('change', toggleFormFields.bind(null, userTypeSelect, ipAddressContainer, clientNameContainer));
      }
  
      function toggleFormFields(userTypeSelect, ipAddressContainer, clientNameContainer) {
          if (userTypeSelect.value === "director") {
              ipAddressContainer.style.display = "block";
          } else {
              ipAddressContainer.style.display = "none";
          }
  
          if (userTypeSelect.value === "employee") {
              clientNameContainer.style.display = "block";
          } else {
              clientNameContainer.style.display = "none";
          }
      }