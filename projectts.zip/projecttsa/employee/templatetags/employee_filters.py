from django import template
from  approve.models import *

register = template.Library()


@register.filter
def get_value(dictionary, key):
    return dictionary.get(key)


@register.simple_tag
def get_approve_event(client_name, employee_name, day):
    approve_events = Approve.objects.filter(client_name=client_name, employee_name=employee_name, date=day, event_name__gte=0)
    return list(approve_events)
