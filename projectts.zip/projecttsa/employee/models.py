from django.db import models

from django.contrib.auth.models import User

from django.utils import timezone


class CalendarEvent(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    client_name = models.CharField(max_length=25)
    employee_name = models.CharField(max_length=25)
    date = models.DateField()
    # event_name is working hours.
    event_name = models.CharField(max_length=100, default='0')
    addedBy = models.CharField(max_length=50, blank=True, null=True)  
    addedDate = models.DateTimeField(default=timezone.now, null=True)
    rejectedBy = models.CharField(max_length=50, blank=True, null=True)
    rejectedDate = models.DateTimeField(default=None, null=True)


    def __str__(self):
        return f"{self.employee_name} - {self.client_name} - {self.date.strftime('%Y-%m-%d')} - {self.event_name}"

    class Meta:
        unique_together = ['client_name','employee_name', 'date', 'event_name']


class Emails(models.Model):
    client_name = models.CharField(max_length=25,blank=True,null=True)
    employee_name = models.CharField(max_length=100)
    date = models.DateField()
    

    def __str__(self):
        return f"{self.employee_name} - {self.client_name} - {self.date.strftime('%Y-%m-%d')}"
    
    class Meta:
        unique_together = ['client_name','employee_name','date']