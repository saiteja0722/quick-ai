from django.urls import path
from .views import *


urlpatterns=[
    path('', login_view, name='login'),
    path('logout/', logout_view, name='logout'),
    path('register/',hr,name='register'),
    path('site/', site_cant, name='site_cant'),
    path('another/',another_page,name='another_page'),
]