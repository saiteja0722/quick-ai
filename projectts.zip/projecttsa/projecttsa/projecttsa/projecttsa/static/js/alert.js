function confirmSubmit(event) {
    var confirmed = confirm("Email is send to the Approver, Click 'ok' to confirm!..");
    if (!confirmed) {
        event.preventDefault();
    }
}

function deleted(event){
    var confirmed=confirm(`if you click the 'ok' button this employee related entire data will be delete,
                         Click 'ok' to confirm!.. `)
    if(!confirmed){
        event.preventDefault()
    }
}

function client_delete(event){
    var confirmed=confirm("Click 'ok' to confirm!.. ")
    if(!confirmed){
        event.preventDefault()
    }
}

function del(event){
    var confirmed=confirm("Click 'ok' to confirm!.. ")
    if(!confirmed){
        event.preventDefault()
    }
}



// Get the input fields and save button
var inputFields = document.querySelectorAll('input[name="event_name"]');
var saveButton = document.getElementById('save_button');

// Function to check if the save button should be enabled
function checkSaveButton() {
    var shouldEnable = false;
    inputFields.forEach(function(input) {
        if (!input.readOnly && input.value !== "") {
            shouldEnable = true;
        }
    });
    saveButton.disabled = !shouldEnable;
}

// Add event listener to each input field
inputFields.forEach(function(input) {
    input.addEventListener('input', checkSaveButton);
});

// Initially check the save button state
checkSaveButton();


function validateForm() {
    var clientNameInput = document.getElementsByName('client_name')[0];
    var saveButton = document.getElementById('save_button');

    if (clientNameInput.value === '') {
        alert("Please select a client name.");
        clientNameInput.focus(); // Set focus on the input for user attention
        return false; // Prevent form submission
    }

    return true; // Allow form submission
}
