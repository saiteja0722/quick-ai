from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login as auth_login
from .models import *

from django.contrib.auth.models import User

from django.contrib.auth import login, logout
from django.contrib import messages

from django.contrib.auth.decorators import login_required

import datetime

import socket 


from django.db.models import Q

from django.utils import timezone

from django.core.exceptions import ObjectDoesNotExist

from login.models import *
from employee.models import *
from approve.models import *

from login.views import *


from django.http import Http404




@login_required(login_url='/')
def admin_page(request):
    private_ip = None
    if request.method == 'GET':
        # Get the user's IP address
        private_ip = get_physical_mac_address()
        print('Private IP:', private_ip)

        # Check if the user's IP address is allowed
        if not Employee.objects.filter(ip_address=private_ip, user_type='hr').exists():
            count = int(request.session.get('message_count', 0))
            count += 1
            request.session['message_count'] = count
            messages.error(request, 'Your MAC Address does not match')
            return redirect('another_page')

    try:
        employee = request.user.employee
    except ObjectDoesNotExist:
        # Redirect to login or an error page if the user has no employee
        return redirect('login')

    if employee.user_type != 'hr':
        return redirect('login')

    if request.method == 'POST':

        if 'add' in request.POST:
            name = request.POST['name']
            employee_id = request.POST['employee_id']
            email=request.POST['email']
            password = request.POST['password']
            user_type = request.POST['user_type']
            ip_address=request.POST['ip_address']
            

            if User.objects.filter(username=name).exists():
                messages.error(request,"Username already exists")
                return redirect('admin_page')

            user = User.objects.create_user(username=name, password=password)
            employee = Employee(user=user, employee_id=employee_id, email=email, user_type=user_type, ip_address=ip_address)
            employee.save()

            # Create or update LogData entry for 'add' action
            log_data, created = LogData.objects.get_or_create(employee_name=name)
            log_data.addedBy = request.user.username
            log_data.addedDate = timezone.now()
            log_data.save()

            messages.success(request,"Data will be registred successfully!..")
            return redirect('admin_page')
        
        elif 'search' in request.POST:
            search_query = request.POST.get('search_name')
            try:
                instance = Employee.objects.get(user__username=search_query)  
                context = {'retrieved_data': instance.employee_id, 'employee_details': instance}  
                return render(request, 'admin_page.html', context)
            except Employee.DoesNotExist:
                messages.error(request,"Employee Not Found")
                return redirect('admin_page')

        elif 'update' in request.POST:
            updated_name = request.POST.get('update_name')
            updated_email = request.POST.get('update_email')
            updated_employee_id = request.POST.get('update_employee_id')
            updated_user_type = request.POST.get('update_user_type')
            updated_password = request.POST.get('update_password', None)
            updated_ip_address = request.POST.get('update_ip_address')

            instance_id = request.POST.get('instance_id')

            if instance_id:
                try:
                    instance = Employee.objects.get(pk=instance_id)
                    instance.user.username = updated_name
                    instance.email = updated_email
                    instance.user_type = updated_user_type
                    instance.employee_id = updated_employee_id
                    instance.ip_address = updated_ip_address

                    if updated_password:  # Check if a new password is provided
                        instance.user.set_password(updated_password)  # Update the password using set_password method

                    instance.user.save()  # Save the changes to the User model
                    instance.save()  # Save the changes to the Employee model
                    messages.success(request, "Data will be updated successfully!..")

                    # Create or update LogData entry for 'update' action
                    log_data, created = LogData.objects.get_or_create(employee_name=updated_name)
                    log_data.updatedBy = request.user.username
                    log_data.updatedDate = timezone.now()
                    log_data.save()

                    return redirect('admin_page')
                except Employee.DoesNotExist:
                    messages.error(request, "Employee not found")
                    return redirect('admin_page')
            else:
                messages.error(request, "Invalid instance ID")
                return redirect('admin_page')

            
            
        elif 'search_delete' in request.POST:
            search_query = request.POST.get('search_name')
            try:
                instance = Employee.objects.get(user__username=search_query)  
                context = {'retrieved_data': instance.employee_id, 'delete_details': instance}  
                return render(request, 'admin_page.html', context)
            except Employee.DoesNotExist:
                messages.error(request,"Employee Not Found")
                return redirect('admin_page')
            
        elif 'delete' in request.POST:
            employee_name = request.POST.get('employee_name')

            if employee_name:
                try:
                    # Delete Employee
                    employee = Employee.objects.get(user__username=employee_name)
                    user = employee.user
                    employee.delete()
                    user.delete()

                    # Delete related data from other models
                    CalendarEvent.objects.filter(employee_name=employee_name).delete()
                    Approve.objects.filter(employee_name=employee_name).delete()
                    Emails.objects.filter(employee_name=employee_name).delete()
                    

                    # Create or update LogData entry for 'delete' action
                    log_data, created = LogData.objects.get_or_create(employee_name=employee_name)
                    log_data.deletedBy = request.user.username
                    log_data.deletedDate = timezone.now()
                    log_data.save()

                    messages.success(request, "Data deleted successfully!")
                except Employee.DoesNotExist:
                    messages.error(request, "Employee not found")
            else:
                messages.error(request, "Invalid employee name")

            return redirect('admin_page')


     # Filter data based on the user type before passing it to the template
    if employee.user_type == 'hr':
        instances = Employee.objects.all()
    else:
        instances = Employee.objects.filter(user_type='employee')
        
    context = {'private_ip':private_ip,'instances': instances} 
    return render(request, 'admin_page.html', context)




@login_required(login_url='/')
def hr_ip_addresses(request):
    if not request.user.is_authenticated or request.user.employee.user_type != 'hr':
        return redirect('login')

    if request.method == 'POST':
        employee_name = request.POST.get('employee_name')
        ip_address = request.POST.get('ip_address')

        update_instance, _ = HrIPAddress.objects.get_or_create(pk=1)
        update_instance.employee_name = employee_name
        update_instance.ip_address = ip_address
        update_instance.save()

    update = HrIPAddress.objects.all()
    context = {'update': update}
    return render(request, "hr_ip_address.html", context)




@login_required(login_url='/')
def Log_data(request):
    if not request.user.is_authenticated or request.user.employee.user_type != 'hr':
        return redirect('login')
    # Retrieve records from both models and combine them into a single list
    CalendarEvent_records = CalendarEvent.objects.all()
    approve_records = Approve.objects.all()
    
    # Create a dictionary to group records based on 'employee_name' and 'date'
    records_dict = {}
    for record in CalendarEvent_records:
        key = (record.client_name ,record.employee_name, record.date)
        records_dict.setdefault(key, {}).update({'addedBy': record.addedBy, 'addedDate': record.addedDate,
                                                  'rejectedBy': record.rejectedBy, 'rejectedDate': record.rejectedDate})

    for record in approve_records:
        key = (record.client_name ,record.employee_name, record.date)
        records_dict.setdefault(key, {}).update({'approvedBy': record.approvedBy, 'approvedDate': record.approvedDate})

    # Filter the records to exclude rows where both 'addedBy' and 'addedDate' are None or empty strings
    filtered_records = [
        {
            'addedBy': record.get('addedBy', ''),
            'addedDate': record.get('addedDate', ''),
            'approvedBy': record.get('approvedBy', ''),
            'approvedDate': record.get('approvedDate', ''),
            'rejectedBy': record.get('rejectedBy',''),
            'rejectedDate': record.get('rejectedDate','')
        }
        for record in records_dict.values()
        if record.get('addedBy') is not None and record.get('addedDate')
    ]

    # Sort the filtered records based on 'addedDate' with a default value for None
    sorted_records = sorted(filtered_records, key=lambda obj: (obj['addedDate'] if obj['addedDate'] else timezone.make_aware(datetime.datetime(1970, 1, 1))))
    instances=LogData.objects.all()
    context = {
        'records': sorted_records,
        'instances':instances,
    }

    return render(request, 'log_data.html', context)


@login_required(login_url='/')
def client_store(request):
    if not request.user.is_authenticated or request.user.employee.user_type!= 'hr':
        return redirect('login')
    
    if request.method == 'POST':
        
        if 'add' in request.POST:
            clients=request.POST['clients']
            
            if ClientName.objects.filter(clients=clients).exists():
                messages.error(request, "Client name already exists")
                return redirect('client_store')
            
            my_client=ClientName(clients=clients)
            my_client.save()
            messages.success(request, "Client name added successfully")
            return redirect('client_store')
        
        elif 'search' in request.POST:
            search_query = request.POST.get('search_name')
            try:
                instance=ClientName.objects.get(clients=search_query)
                context={'client_details': instance}
                return render(request, 'client_page.html', context)
            except ClientName.DoesNotExist:
                messages.error(request, "Client name not found")
                return redirect('client_store')
            
        elif 'update' in request.POST:
            updated_clients=request.POST.get('update_clients')
            
            instance_id=request.POST.get('instance_id')
            
            if instance_id:
                try:
                    instance=ClientName.objects.get(pk=instance_id)
                    instance.clients=updated_clients
                    instance.save()
                    messages.success(request, "Client name updated successfully")
                    return redirect('client_store')
                except ClientName.DoesNotExist:
                    messages.error(request, "Client name not found")
                    return redirect('client_store')
                
            else:
                messages.error(request, "Invalid instance ID")
                return redirect('client_store')
            
        elif 'search_delete' in request.POST:
            search_query = request.POST.get('search_name')
            try:
                instance=ClientName.objects.get(clients=search_query)
                context={'delete_details': instance}
                return render(request, 'client_page.html', context)
            except ClientName.DoesNotExist:
                messages.error(request, "Client name not found")
                return redirect('client_store')
            
        elif 'delete' in request.POST:
            clients=request.POST.get('clients')
            
            if clients:
                try:
                    client=ClientName.objects.get(clients=clients)
                    client.delete()
                
                    messages.success(request, "Client name deleted successfully")
                    
                except ClientName.DoesNotExist:
                    messages.error(request, "Client name not found")
            else:
                messages.error(request, "Invalid client name")
            return redirect('client_store')
    
    instances=ClientName.objects.all()
    context={'instances': instances}
    return render(request,'client_page.html', context)

    
                
                

            
            
            
    
    
    
    
        