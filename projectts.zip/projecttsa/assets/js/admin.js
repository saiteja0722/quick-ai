let dropDownAdd = document.getElementById("drop-down-add");
let dropDownContAdd = document.getElementById("drop-down-cont-add");


let dropDownUpdate = document.getElementById("drop-down-update");
let dropDownContUpdate = document.getElementById("drop-down-cont-update")

let dropDownDelete = document.getElementById("drop-down-delete");
let dropDownContDelete = document.getElementById("drop-down-cont-delete")

dropDownAdd.onclick = function() {
    dropDownContAdd.classList.toggle("drop-down-cont-add");
    dropDownContUpdate.classList.toggle("drop-down-cont-update");
    dropDownContDelete.classList.toggle("drop-down-cont-delete");
}

dropDownUpdate.onclick = function() {
    dropDownContUpdate.classList.toggle("drop-down-cont-update");
}

dropDownDelete.onclick = function() {
    dropDownContDelete.classList.toggle("drop-down-cont-delete");
}

