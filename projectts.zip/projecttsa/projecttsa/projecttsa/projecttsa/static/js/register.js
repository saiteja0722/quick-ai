document.getElementById('main').addEventListener('submit', function (event) {
    var user_type = document.getElementById('user_type');
    
    if (user_type.selectedIndex === 0) {
        event.preventDefault(); // Prevent form submission
        alert('Please select a valid user type.');
    }
});

