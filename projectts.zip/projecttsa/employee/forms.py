from django import forms
from .models import *

# employees
class CalendarEventForm(forms.ModelForm):
    class Meta:
        model = CalendarEvent
        fields = ['client_name', 'employee_name', 'date', 'event_name']
        








