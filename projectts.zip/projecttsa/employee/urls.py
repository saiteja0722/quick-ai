from django.urls import path
from .views import *

urlpatterns=[
    path('', calendar_view, name='calendar'),
    path('data/', data, name='data'),
]